// src/components/EmployerRegistration.jsx

import React from "react";

const EmployerRegistration = () => {
  return (
    <div>
      <h3 className="text-xl mb-4">Employer Registration</h3>
      <form>
        <div className="mb-4">
          <label className="block">Company Name</label>
          <input
            type="text"
            className="w-full p-2 border border-gray-300 rounded"
            placeholder="Enter your company name"
          />
        </div>
        <div className="mb-4">
          <label className="block">Email</label>
          <input
            type="email"
            className="w-full p-2 border border-gray-300 rounded"
            placeholder="Enter your email"
          />
        </div>
        <button className="w-full py-2 bg-blue-500 text-white rounded">Register</button>
      </form>
    </div>
  );
};
const handleSubmit = (event) => {
  event.preventDefault();
  // Basic validation logic
  const companyName = document.getElementById("companyName").value;
  if (!companyName) {
    alert("Company Name is required");
  } else {
    // Proceed with registration
    console.log("Employer registered!");
  }
};


export default EmployerRegistration;
