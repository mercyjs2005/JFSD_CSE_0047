// src/components/RoleSelection.jsx

import React from "react";
import { useNavigate } from "react-router-dom";

const RoleSelection = () => {
  const navigate = useNavigate();

  const handleRoleSelect = (role) => {
    navigate(`/register/${role}`);
  };

  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <div className="text-center p-8 bg-white shadow-lg rounded-lg">
        <h2 className="text-2xl mb-4">Welcome to JobMatch</h2>
        <p className="mb-6">Please select your role</p>
        <div className="space-x-4">
          <button
            onClick={() => handleRoleSelect("employer")}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg"
          >
            Employer
          </button>
          <button
            onClick={() => handleRoleSelect("jobseeker")}
            className="px-4 py-2 bg-green-500 text-white rounded-lg"
          >
            Job Seeker
          </button>
        </div>
      </div>
    </div>
  );
};

export default RoleSelection;
