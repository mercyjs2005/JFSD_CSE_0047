// src/components/JobSeekerRegistration.jsx

import React from "react";

const JobSeekerRegistration = () => {
  return (
    <div>
      <h3 className="text-xl mb-4">Job Seeker Registration</h3>
      <form>
        <div className="mb-4">
          <label className="block">Full Name</label>
          <input
            type="text"
            className="w-full p-2 border border-gray-300 rounded"
            placeholder="Enter your full name"
          />
        </div>
        <div className="mb-4">
          <label className="block">Email</label>
          <input
            type="email"
            className="w-full p-2 border border-gray-300 rounded"
            placeholder="Enter your email"
          />
        </div>
        <div className="mb-4">
          <label className="block">Skills</label>
          <input
            type="text"
            className="w-full p-2 border border-gray-300 rounded"
            placeholder="Enter your skills"
          />
        </div>
        <button className="w-full py-2 bg-green-500 text-white rounded">Register</button>
      </form>
    </div>
  );
};

export default JobSeekerRegistration;
