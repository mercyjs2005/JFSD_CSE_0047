// LandingPage.js
import React from 'react';

const LandingPage = () => {
  return (
    <div className="bg-3d bg-cover bg-fixed text-white">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 w-full bg-opacity-80 bg-indigo-700 p-4 shadow-md z-50">
        <div className="container mx-auto flex justify-between items-center">
          <div className="text-3xl font-bold text-white">JobMatch</div>
          <div className="space-x-6">
            <a href="#" className="text-lg hover:text-indigo-300">Home</a>
            <a href="#about" className="text-lg hover:text-indigo-300">About</a>
            <a href="#contact" className="text-lg hover:text-indigo-300">Contact</a>
          </div>
        </div>
      </nav>

      {/* Landing Page */}
      <div className="flex items-center justify-center h-screen text-center">
        <div className="space-y-8">
          <h1 className="text-6xl font-extrabold leading-tight">Welcome to JobMatch</h1>
          <p className="text-2xl">Find your next job or hire top talent today!</p>
          <div className="flex justify-center space-x-4">
            <button className="px-8 py-4 text-lg font-semibold bg-gradient-to-r from-green-400 to-blue-500 hover:bg-gradient-to-l rounded-md transform hover:scale-105 transition duration-300">
              Employer
            </button>
            <button className="px-8 py-4 text-lg font-semibold bg-gradient-to-r from-pink-500 to-purple-600 hover:bg-gradient-to-l rounded-md transform hover:scale-105 transition duration-300">
              Job Seeker
            </button>
          </div>
        </div>
      </div>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-800 text-center">
        <h2 className="text-4xl text-white mb-6">About JobMatch</h2>
        <p className="text-lg text-gray-400 max-w-3xl mx-auto">
          JobMatch is a revolutionary platform designed to connect employers with the best talent and help job seekers land their dream jobs. Our mission is to make the job search process faster, easier, and more effective for everyone.
        </p>
      </section>

      {/* Footer Section */}
      <footer id="contact" className="bg-gray-800 py-6 text-center text-gray-400">
        <p>&copy; 2025 JobMatch. All rights reserved.</p>
        <div className="space-x-4 mt-4">
          <a href="#" className="hover:text-indigo-300">Facebook</a>
          <a href="#" className="hover:text-indigo-300">Twitter</a>
          <a href="#" className="hover:text-indigo-300">LinkedIn</a>
        </div>
      </footer>
    </div>
  );
}

export default LandingPage;
