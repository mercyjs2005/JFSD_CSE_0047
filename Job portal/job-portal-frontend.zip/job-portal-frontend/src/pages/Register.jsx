// src/pages/Register.jsx
import React from "react";
import { useParams } from "react-router-dom";
import EmployerRegistration from "../components/EmployerRegistration";
import JobSeekerRegistration from "../components/JobSeekerRegistration";

const Register = () => {
  const { role } = useParams();

  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <div className="w-full max-w-lg p-8 bg-white shadow-lg rounded-lg">
        {role === "employer" ? (
          <EmployerRegistration />
        ) : role === "jobseeker" ? (
          <JobSeekerRegistration />
        ) : (
          <div>Invalid Role</div>
        )}
      </div>
    </div>
  );
};

export default Register;
