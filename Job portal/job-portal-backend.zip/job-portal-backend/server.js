import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config(); // Load .env file

const app = express();

// Middlewares
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  }));
  
app.use(express.json());

// Sample route to test server
app.get('/test', (req, res) => {
  res.send('Job Portal Backend is Running ✅');
});

// Routes (you'll add actual authRoutes and jobRoutes here soon)
import authRoutes from './routes/authRoutes.js';
// import jobRoutes from './routes/jobRoutes.js';
app.use('/api/auth', authRoutes);
// app.use('/api/jobs', jobRoutes);

// MongoDB connection
mongoose.connect(process.env.MONGO_URI)

.then(() => {
  console.log('Connected to MongoDB ✅');
  app.listen(process.env.PORT, () => {
    console.log(`Server running on port ${process.env.PORT}`);
  });
})
.catch(err => console.error('MongoDB connection error:', err));
